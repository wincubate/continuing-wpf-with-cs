﻿namespace UpdatingCastMembers
{
    class CastMember
    {
        public string Character { get; set; }
        public string ActorName { get; set; }
        public string Image { get; set; }
    }
}
