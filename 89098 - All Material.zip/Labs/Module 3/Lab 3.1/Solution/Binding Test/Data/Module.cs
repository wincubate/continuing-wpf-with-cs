﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BindingTest.Data
{
   public class Module
   {
      public string Title
      {
         get;
         set;
      }
   }
}
